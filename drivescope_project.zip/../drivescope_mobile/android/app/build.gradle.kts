plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
    // 🌟 تم إضافة إضافة الفايربيز هنا
    id("com.google.gms.google-services")
}

android {
    namespace = "com.example.drivescope_mobile"
    compileSdk = flutter.compileSdk

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    defaultConfig {
        applicationId = "com.example.drivescope_mobile"
        // 🌟 تم التعديل لـ 21 لضمان عمل الفايربيز
        minSdk = 21
        targetSdk = flutter.targetSdk
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

flutter {
    source = "../.."
}